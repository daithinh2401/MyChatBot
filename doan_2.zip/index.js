var logger = require('morgan');
var http = require('http');
var bodyParser = require('body-parser');
var express = require('express');
var request = require('request');
var builder = require('botbuilder');
var router = express();
 
var app = express();
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false
}));
var server = http.createServer(app);
 
app.listen(process.env.PORT || 3000);
 

 
app.get('/', (req, res) => {
  res.send("Server chạy ngon lành.");
});
 
app.get('/webhook', function(req, res) {
  if (req.query['hub.verify_token'] === '123') {
    res.send(req.query['hub.challenge']);
  }
  res.send('Error, wrong validation token');
});

var stringHello = ["hi" , "hello" , "chào" , "xin chào"];
var stringBye = ["bye" , "goodbye" , "bye" , "tạm biệt"];


function replyBye(text){
	for( var h of stringBye){
		if(text.toLowerCase() == h)
		{
			return true;
		}
	}
	return false;
}
function replyHello(text){
	for( var h of stringHello){
		if(text.toLowerCase() == h)
		{
			return true;
		}
	}
	return false;
}
 
// Đoạn code xử lý khi có người nhắn tin cho bot
app.post('/webhook', function(req, res) {
  var entries = req.body.entry;
  for (var entry of entries) {
    var messaging = entry.messaging;
    for (var message of messaging) {
      var senderId = message.sender.id;
      if (message.message) {
        // Nếu người dùng gửi tin nhắn đến
        if (message.message.text) {
          var text = message.message.text;
		  if(replyHello(text))
			  sendMessage(senderId , "Xin Chào , tôi là Bot !");
		  else if (replyBye(text))
			  sendMessage(senderId , "Tạm biệt , hẹn gặp lại !");
		  else
			  sendMessage(senderId , "Tôi chưa hiểu !");
        }
      }
    }
  }
 
  res.status(200).send("OK");
});


 
// Gửi thông tin tới REST API để Bot tự trả lời
function sendMessage(senderId, message) {
  request({
    url: 'https://graph.facebook.com/v2.6/me/messages',
    qs: {
      access_token: "EAAGXAMrW1fkBAO5Hlkisin5ss4V5CIaivFC9MZCV1E8eR6ORBIkGCIAGzRfVXWLPN80WFif2bE95cMfljNFTKyGhikqNr3OiOQt53M71KQKyfvaTUkSxgo5xLozFZAzaeNm83GEeiEsZCbZBJ3BkLXm67hveXjWsMiHBCs0MCwZDZD",
    },
    method: 'POST',
    json: {
      recipient: {
        id: senderId
      },
      message: {
        text: message
      },
    }
  });
}
